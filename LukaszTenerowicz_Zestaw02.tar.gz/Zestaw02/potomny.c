#include <stdio.h>
#include "procinfo.h"

int main(int argc, const char* argv[])
{
    procinfo(argv[0]);

    return 0;
}