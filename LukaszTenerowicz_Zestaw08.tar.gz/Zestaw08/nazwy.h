#ifndef NAZWY_H
#define NAZWY_H

const char *serwer = "/serwer";

#endif // NAZWY_H