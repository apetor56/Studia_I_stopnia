#ifndef PROG_H
#define PROG_H

void fun(int file_des, int option);

#endif // PROG_H