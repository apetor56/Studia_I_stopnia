#ifndef PROCINFO_H
#define PROCINFO_H

int procinfo(const char* name);

#endif /* PROCINFO_H */

